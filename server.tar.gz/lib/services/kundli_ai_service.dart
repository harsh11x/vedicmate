class KundliAIService {
  KundliAIService();
}
