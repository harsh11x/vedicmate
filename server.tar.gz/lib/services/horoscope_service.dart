class HoroscopeService {
  HoroscopeService();
}
