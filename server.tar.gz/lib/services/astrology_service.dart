class AstrologyService {
  AstrologyService();
}
